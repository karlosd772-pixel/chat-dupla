# 📱 Chat da Dupla — versão para gerar APK pelo celular

Esta versão foi preparada para você **não precisar de computador para compilar**.
O projeto usa GitHub Actions para montar a estrutura Android do Flutter e gerar o APK na nuvem.

## O que você precisa no celular

- Uma conta no GitHub.
- O navegador do celular.
- O arquivo `google-services.json` do seu projeto Firebase.

## Passo a passo

### 1. Criar um repositório no GitHub

No GitHub, crie um repositório novo, por exemplo `chat-dupla`.

Envie **todo o conteúdo desta pasta** para o repositório, mantendo principalmente:

- `pubspec.yaml`
- `lib/main.dart`
- `.github/workflows/build-apk.yml`
- `README.md`
- `README-CELULAR.md`

### 2. Colocar o Firebase

No Firebase Console, crie/configure seu app Android e baixe `google-services.json`.

No GitHub, crie estas pastas se ainda não existirem:

`android/app/`

Depois coloque dentro dela:

`google-services.json`

**Não coloque senhas, chaves privadas ou tokens de servidor no repositório.** O `google-services.json` do Firebase Android é usado como configuração do app; chaves privadas de servidor nunca devem ser colocadas nele.

### 3. Gerar o APK

No GitHub, abra a aba **Actions**.

Escolha **Gerar APK Android** e toque em **Run workflow**.

Aguarde o processo terminar com ✓.

### 4. Baixar no celular

Abra a execução concluída e procure **Artifacts**.

Baixe `chat-dupla-apk`.

Dentro dele estará `app-release.apk`.

Instale o APK no Android.

## Firebase

O aplicativo precisa de:

- Authentication > Anonymous
- Realtime Database
- Cloud Messaging, se você quiser notificações

No `lib/main.dart`, os dois celulares precisam usar o mesmo `pairId`, mas cada um deve ter seu próprio `meuApelido`.

## Importante

As regras do Realtime Database do README original são adequadas somente para testes privados. Antes de publicar para outras pessoas, restrinja o acesso da conversa aos usuários autorizados.
