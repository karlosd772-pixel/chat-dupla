# Chat da Dupla

Protótipo Flutter para Android de um chat privado entre duas pessoas.

## Já incluído
- Tema escuro e tela de conversa.
- Status `Ativo agora` baseado em presença no Firebase Realtime Database.
- Uma dupla fixa identificada por `PAIR_ID` e dois apelidos.
- Mensagens sincronizadas em tempo real.
- Login anônimo, sem tela de senha.
- Base para notificações em segundo plano usando Firebase Cloud Messaging.

## Antes de executar
1. Instale Flutter e Android Studio no computador.
2. No Firebase Console, crie um projeto Android e baixe `google-services.json`.
3. Coloque o arquivo em `android/app/google-services.json`.
4. No arquivo `lib/main.dart`, altere `PAIR_ID`, `MEU_APELIDO` e `APELIDO_AMIGO` nos dois celulares:
   - Os dois devem usar o mesmo `PAIR_ID`.
   - Cada APK deve ter seu próprio `MEU_APELIDO`.
5. Ative no Firebase: Authentication > Anonymous, Realtime Database e Cloud Messaging.
6. Execute `flutter pub get` e `flutter run`.

## Regras mínimas do Realtime Database
Durante testes privados, use regras autenticadas. Para publicar, limite a conversa aos dois UID autorizados:

```json
{
  "rules": {
    ".read": "auth != null",
    ".write": "auth != null"
  }
}
```

## Notificações
O envio de push para outro aparelho não deve ser feito diretamente pelo app com uma chave secreta. Use uma Cloud Function, servidor próprio ou outro backend para chamar o FCM de modo seguro.

## Android
No primeiro teste, permita notificações. Para usar bolhas, o usuário também deve habilitá-las nas configurações de notificação do Android.

## 📱 Gerar APK somente pelo celular

Veja `README-CELULAR.md`. Esta versão inclui um workflow do GitHub Actions que cria a estrutura Android completa e gera o APK na nuvem, sem exigir Android Studio no celular.
