import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

// CONFIGURE UMA VEZ EM CADA CELULAR.
// Os dois aparelhos usam o mesmo pairId. Troque somente meuApelido.
const String pairId = 'dupla-voce-e-amigo';
const String meuApelido = 'Você';
const String apelidoAmigo = 'Seu Amigo';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await FirebaseAuth.instance.signInAnonymously();
  runApp(const ChatDuplaApp());
}

class ChatDuplaApp extends StatelessWidget {
  const ChatDuplaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Chat da Dupla',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4F8CFF), brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF101216),
      ),
      home: const ChatPage(),
    );
  }
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with WidgetsBindingObserver {
  final _controller = TextEditingController();
  late final DatabaseReference _base;
  late final DatabaseReference _presence;
  StreamSubscription<DatabaseEvent>? _presenceSub;
  bool _friendOnline = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final uid = FirebaseAuth.instance.currentUser!.uid;
    _base = FirebaseDatabase.instance.ref('pairs/$pairId');
    _presence = _base.child('presence/$uid');
    _enablePresence();
    _presenceSub = _base.child('presence').onValue.listen((event) {
      final value = event.snapshot.value;
      final map = value is Map ? Map<String, dynamic>.from(value) : <String, dynamic>{};
      final friendIsOnline = map.entries.any((entry) => entry.key != uid && entry.value == true);
      if (mounted) setState(() => _friendOnline = friendIsOnline);
    });
  }

  Future<void> _enablePresence() async {
    await _presence.onDisconnect().set(false);
    await _presence.set(true);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _presence.set(true);
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      _presence.set(false);
    }
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    _controller.clear();
    await _base.child('messages').push().set({
      'text': text,
      'senderId': FirebaseAuth.instance.currentUser!.uid,
      'senderName': meuApelido,
      'sentAt': ServerValue.timestamp,
    });
  }

  @override
  void dispose() {
    _presence.set(false);
    _presenceSub?.cancel();
    _controller.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final messages = _base.child('messages').orderByChild('sentAt');
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF171A20),
        titleSpacing: 8,
        title: Row(children: [
          CircleAvatar(
            backgroundColor: const Color(0xFF2D6CDF),
            child: Text(apelidoAmigo.isNotEmpty ? apelidoAmigo[0].toUpperCase() : '?'),
          ),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(apelidoAmigo, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            Row(children: [
              Icon(Icons.circle, size: 9, color: _friendOnline ? const Color(0xFF46D683) : Colors.grey),
              const SizedBox(width: 5),
              Text(_friendOnline ? 'Ativo agora' : 'Offline', style: const TextStyle(fontSize: 12)),
            ]),
          ]),
        ]),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert))],
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<DatabaseEvent>(
            stream: messages.onValue,
            builder: (context, snapshot) {
              final raw = snapshot.data?.snapshot.value;
              final entries = raw is Map ? raw.entries.toList() : [];
              entries.sort((a, b) {
                final aa = (a.value as Map)['sentAt'] as int? ?? 0;
                final bb = (b.value as Map)['sentAt'] as int? ?? 0;
                return aa.compareTo(bb);
              });
              if (entries.isEmpty) {
                return const Center(child: Text('Mande a primeira mensagem para seu amigo.'));
              }
              return ListView.builder(
                reverse: true,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                itemCount: entries.length,
                itemBuilder: (context, index) {
                  final data = Map<String, dynamic>.from(entries[entries.length - 1 - index].value as Map);
                  final mine = data['senderId'] == FirebaseAuth.instance.currentUser!.uid;
                  return _MessageBubble(text: '${data['text'] ?? ''}', mine: mine);
                },
              );
            },
          ),
        ),
        SafeArea(
          top: false,
          child: Container(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
            color: const Color(0xFF171A20),
            child: Row(children: [
              IconButton(onPressed: () {}, icon: const Icon(Icons.add_circle_outline)),
              Expanded(
                child: TextField(
                  controller: _controller,
                  minLines: 1,
                  maxLines: 4,
                  onSubmitted: (_) => _send(),
                  decoration: InputDecoration(
                    hintText: 'Escreva uma mensagem…',
                    filled: true,
                    fillColor: const Color(0xFF252A33),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                  ),
                ),
              ),
              IconButton(onPressed: _send, icon: const Icon(Icons.send_rounded, color: Color(0xFF7EADFF))),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final String text;
  final bool mine;
  const _MessageBubble({required this.text, required this.mine});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 290),
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: mine ? const Color(0xFF2D6CDF) : const Color(0xFF292E37),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(mine ? 18 : 4),
            bottomRight: Radius.circular(mine ? 4 : 18),
          ),
        ),
        child: Text(text, style: const TextStyle(fontSize: 16)),
      ),
    );
  }
}
